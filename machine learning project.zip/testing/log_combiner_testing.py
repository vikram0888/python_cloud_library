from data_access_layer.mongo_db.mongo_db_atlas import MongoDBOperation
from project_library_layer.initializer.initializer import Initializer
from dateutil.parser import parse
import pandas as pd
mongo_db = MongoDBOperation()

execution_id = '1b6ef9c5-05ed-457e-b493-928af58ebe9a'
project_id = 2

data_time='2021-04-05 10:13:54'





"""

"""
