from encryption.encrypt_confidential_data import EncryptData
import sys,os
import uuid
from datetime import datetime
from data_access_layer.mongo_db.mongo_db_atlas import MongoDBOperation
from logging_layer.mongo_db_atlas.mogo_db_logger import LoggerMongoDB
from project_library_layer.datetime_libray import date_time
if __name__ == "__main__":
    try:
        start_time=date_time.get_time()
        start_date=date_time.get_date()
        logger_mongodb=LoggerMongoDB(uuid.uuid4().__str__())
        encrypt=EncryptData()
        encrypt.get_encrypted_text(None)
    except Exception as e:
        print(e)
        exc_type, exc_obj, exc_tb = sys.exc_info()
        file_name = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        exception_type=e.__repr__()
        exception_detail={'start_date':start_date,'start_time':start_time,'exception_type':exception_type, 'file_name':file_name, 'line_number':exc_tb.tb_lineno ,'detail':sys.exc_info().__str__()}
        logger_mongodb.log("ExceptionCollection",exception_type,exception_detail)

